<!DOCTYPE html>
<html lang='en'>

<head>
    <meta charset="utf-8" />
    <meta name="description" content="RV Senpai Project/Assignment" />
    <meta name="keywords" content="RV, Senpai, Enhancements Page" />
    <meta name="author" content="Ericson Tan Peng Hong, Loo Wei Jit, Raymond Sii Li Sheng, Ian Chung Ye Earn" />
	
    <title>Enhancements | RV Senpai</title>
	
	<link rel="stylesheet" type="text/css" href="styles/style.css"/>
	<!-- Link for social media -->
	<!-- https://www.w3schools.com/howto/howto_css_social_media_buttons.asp -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"/>
	
	
	
</head>

<body>

<header>

	<?php
		include_once 'backtotop&scroll.php'
	?>
	<nav>
	<?php
			include_once 'logo.php'
		?>
		<ul>
			<li><a href="index.php" title="RV Senpai HomePage">Home</a></li>
			<li><a href="aboutus.php" title="About RV Senpai">About Us</a></li>
			<li><div class="product_dropdown">
					<a class="dropbtn" href="product.php" title="RV Senpai RVs">Rental</a>
					<div id="product_dropdown_id" class="product_dropdown_content"></div>
				</div>
				</li>
			<li><a class="booking" href="enquiry.php" title="Rent Your RV Here">Booking</a></li>
			<li><a href="event.php" title="Event RV Senpai">Event</a></li>
			<li><a href="contactus.php" title="Contact RV Senpai">Contact Us</a></li>
			<li><button class="login" onclick="document.getElementById('id01').style.display='block'" style="width:auto;"><strong>Login</strong></button></li>
		</ul>
	</nav>
	
	

	
	
<!-- Login -->
<!-- Start here -->
<div id="id01" class="modal">
  <form class="modal-content animate" action="/action_page.php">
    <div class="imgcontainer">
      <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
      <img src="images/avatar.png" alt="Avatar" class="avatar" />
    </div>

    <div class="container">
      <label for="uname"><b>Email</b></label>
      <input type="text" class="log" placeholder="Enter Username" name="uname" required="requried" />
        
      <button type="submit" class="login login_nav">Login</button>
    </div>

    <div class="container" style="background-color:#f1f1f1">
      <button type="button" class="login cancelbtn" onclick="document.getElementById('id01').style.display='none'">Cancel</button>
    </div>
  </form>
</div>
<!-- End here -->

</header>

	<div class="bigimg_enhancement">
		<div class="caption">
		<h1><span class="border">RV Senpai</span></h1>
		</div>
	</div>

	<article class="article_area">
		<h3 class="h3_black_background">Enhancements</h3>
		<h4>HTML and CSS</h4>
		<p>Google Map Embed inside contactus.html and index.html - Link <a target="_blank" class="enhancement" href="contactus.php">Contact US</a> and <a target="_blank" class="enhancement" href="index.php">Homepage</a></p>
		<p>Navigation Bar Product will drop down when hover - Link <a target="_blank" class="enhancement" href="https://www.w3schools.com/css/css_dropdowns.asp">W3School example</a></p>
		<p>Overlay content will appear at the right side when hover in product.html - Link <a target="_blank" class="enhancement" href="product.php">Rental</a></p>
		<p>Parallax background image in all pages learnt - Link <a target="_blank" class="enhancement" href="https://www.w3schools.com/howto/tryhow_css_parallax_demo.htm"> W3School example</a></p>
		<p>Zoom in when hover to member image in aboutus.html - Link <a target="_blank" class="enhancement" href="aboutus.php">About Us</a></p>
		<p>All of this enhancement mostly can be found and learned in W3School. The team find that W3School is a very powerful website where all html, css, jss and php resources are available. The team feel accomplish whenever team members had successfully develop the enhancements with current html and css</p>
	</article>
	
	<div class="bigimg_enhancement">
		<div class="caption">
		<h2><span class="border2">Enhancements</span></h2>
		</div>
	</div>

	
<footer>

		<ul>
			<li><a href="partnership.php" title="RV Senpai Partners">Partnership</a></li>
			<li><a href="faq.php" title="RV Senpai FAQ">FAQ</a></li>
			<li><a href="photo.php" title="Photo Gallery">Photo Gallery</a></li>
			<li><a href="feedback.php" title="RV Senpai Feedback Form">Feedback</a></li>
			<li><a class="footer_active" href="enhancements.php" title="RV Senpai Website Enhancements">Enhancements</a></li>
			<li><a href="enhancements2.php" title="RV Senpai Website Enhancements">Enhancements2</a></li>
			<li><a href="disclaimer.php" title="Disclaimer">Disclaimer</a></li>
		</ul>
		
	<?php
		include_once 'footer_link.php'
	?>

	
	
</footer>
</body>
<script src="script/script.js"></script>
<script src="script/enhancements.js"></script>
</html>
