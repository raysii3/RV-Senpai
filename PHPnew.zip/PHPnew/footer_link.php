<div class="footer_followus">
	<a href="https://www.instagram.com/" target="_blank" class="fa fa-instagram" title="RV Senpai Instagram"></a>
	<a href="https://www.facebook.com/" target="_blank" class="fa fa-facebook" title="RV Senpai Facebook"></a>
	<a href="https://twitter.com/" target="_blank" class="fa fa-twitter" title="RV Senpai Twitter"></a>
	<a href="https://www.pinterest.com/" target="_blank" class="fa fa-pinterest" title="RV Senpai Pinterest"></a>
	<a href="https://www.snapchat.com/" target="_blank" class="fa fa-snapchat-ghost" title="RV Senpai Snapchat"></a>
	<a href="https://www.google.com/" target="_blank" class="fa fa-google" title="RV Senpai Google Page"></a>
	<a href="https://www.youtube.com/" target="_blank" class="fa fa-youtube" title="RV Senpai Youtube Channel"></a>
</div>
<div class="copyright">
	<p>@ Amazing Retards | Page developed by Ericson Tan Peng Hong, Loo Wei Jit, Raymond Sii Li Sheng, Ian Chung Ye Earn | Last updated: 24 March 2018</p>
</div>