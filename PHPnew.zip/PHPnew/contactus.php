<!DOCTYPE html>
<html lang='en'>

<head>
    <meta charset="utf-8" />
    <meta name="description" content="RV Senpai Project/Assignment" />
    <meta name="keywords" content="RV, Senpai, Contact RV Senpai" />
    <meta name="author" content="Ericson Tan Peng Hong, Loo Wei Jit, Raymond Sii Li Sheng, Ian Chung Ye Earn" />
	
    <title>Contact RV Senpai | RV Senpai</title>
	
	<link rel="stylesheet" type="text/css" href="styles/style.css"/>
	<!-- Link for social media -->
	<!-- https://www.w3schools.com/howto/howto_css_social_media_buttons.asp -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"/>
	
	
</head>

<body>

<header>

	<?php
		include_once 'backtotop&scroll.php'
	?>
	<nav>
	<?php
		include_once 'logo.php'
	?>
		<ul>
			<li><a href="index.php" title="RV Senpai HomePage">Home</a></li>
			<li><a href="aboutus.php" title="About RV Senpai">About Us</a></li>
			<li><div class="product_dropdown">
					<a class="dropbtn" href="product.php" title="RV Senpai RVs">Rental</a>
					<div id="product_dropdown_id" class="product_dropdown_content"></div>
				</div>
				</li>
			<li><a class="booking" href="enquiry.php" title="Rent Your RV Here">Booking</a></li>
			<li><a href="event.php" title="Event RV Senpai">Event</a></li>
			<li><a class="active" href="contactus.php" title="Contact RV Senpai">Contact Us</a></li>
		<li><button class="login" onclick="document.getElementById('id01').style.display='block'" style="width:auto;"><strong>Login</strong></button></li>
		</ul>
	</nav>
	
	

	
	
<!-- Login -->
<!-- Start here -->
<div id="id01" class="modal">
  <form class="modal-content animate" action="/action_page.php">
    <div class="imgcontainer">
      <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
      <img src="images/avatar.png" alt="Avatar" class="avatar" />
    </div>

    <div class="container">
      <label for="uname"><b>Email</b></label>
      <input type="text" class="log" placeholder="Enter Username" name="uname" required="requried" />
        
      <button type="submit" class="login login_nav">Login</button>
    </div>

    <div class="container" style="background-color:#f1f1f1">
      <button type="button" class="login cancelbtn" onclick="document.getElementById('id01').style.display='none'">Cancel</button>
    </div>
  </form>
</div>
<!-- End here -->

</header>

	
	<div class="bigimg_contactus">
		<div class="caption">
		<h1><span class="border">Adventure</span></h1>
		</div>
	</div>

	<article>
		<div class="article_area">
			<h3 class="h3_black_background">Contact Us</h3>
			<h4>We Will Be There For You</h4>
			<div id="map_block">
			<iframe id="map" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3988.3916672644277!2d110.3550372147541!3d1.5322625988825767!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31fba70b11e02ce7%3A0x69cbf290cfd24bb7!2sSwinburne+University+of+Technology+Sarawak+Campus!5e0!3m2!1sen!2smy!4v1521882120760" ></iframe>
			</div>
		
			<div class="contact_info">
				<p>Swinburne University of Technology Sarawak Campus Jalan Simpang Tiga 93350 Kuching, Sarawak, Malaysia</p>
				<p>t: +60 82 415 353</p>
				<p>f: +60 82 428 353</p>
				<p>Any Question?<a href="mailto:100079958@students.swinburne.edu.my" target="-top" title="RV Senpai Email">Email Us</a></p>
			</div>
		</div>
	
		<h3>Enquiry</h3>
		<h4 class="white_bg">Send Us A Message</h4>
		
		<form method="post" action="form.php" id="contactus_form">
		<fieldset>
		<legend>Personal Information</legend>
		<table>
			<tr>
				<th>
					<label for="name">Name: </label>
					<input type="text" name="name" id="name" maxlength="50" size="30" required="required" pattern="^[a-zA-Z ]+$" placeholder="Your Name"/>
				</th>
			</tr>
			<tr>
				<th>
					<label for="email">Email: </label>
					<input type="email" name="email" id="email" maxlength="50" size="30" required="required" placeholder="Your email"/>
				</th>
			</tr>
		</table>
		</fieldset><!--personal_info-->
	
		<fieldset>
		<legend>Comments</legend>
		<table>
			<tr>
				<td>
					<textarea name="comment" id="comment" rows="10" cols="50" placeholder="Send us your questions"></textarea>
				</td>
			</tr>
		</table>
		</fieldset>
		
		<table>
			<tr>
				<td>
					<p class="button"><input type="submit" value="Submit"/></p>
				</td>
				<td>
					<p class="button"><input type="reset" value="Reset"/></p>
				</td>
			</tr>
		</table>
		</form>
	</article>
	
	<div class="bigimg_contactus">
		<div class="caption">
		<h1><span class="border">Is Worthwhile</span></h1>
		</div>
	</div>
	
<footer>

		<ul>
			<li><a href="partnership.php" title="RV Senpai Partners">Partnership</a></li>
			<li><a href="faq.php" title="RV Senpai FAQ">FAQ</a></li>
			<li><a href="photo.php" title="Photo Gallery">Photo Gallery</a></li>
			<li><a href="feedback.php" title="RV Senpai Feedback Form">Feedback</a></li>
			<li><a href="enhancements.php" title="RV Senpai Website Enhancements">Enhancements</a></li>
			<li><a href="enhancements2.php" title="RV Senpai Website Enhancements">Enhancements2</a></li>
			<li><a href="disclaimer.php" title="Disclaimer">Disclaimer</a></li>
		</ul>
	
	<?php
		include_once 'footer_link.php'
	?>

	
	
</footer>
</body>
<script src="script/script.js"></script>
<script src="script/enhancements.js"></script>
</html>
