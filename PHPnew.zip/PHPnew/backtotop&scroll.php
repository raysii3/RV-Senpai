<button onclick="topFunction()" class="mybtn" title="Go to top">Top</button>
<div class="scroll_bar">
	<div class="progress-container">
		<div class="progress-bar" id="myBar"></div>
	</div>  
</div> 