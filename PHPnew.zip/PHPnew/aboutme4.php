<!DOCTYPE html>
<html lang='en'>

<head>
    <meta charset="utf-8" />
    <meta name="description" content="RV Senpai Project/Assignment" />
    <meta name="keywords" content="RV, Senpai, Ian Chung Ye Earn" />
    <meta name="author" content="Ericson Tan Peng Hong, Loo Wei Jit, Raymond Sii Li Sheng, Ian Chung Ye Earn" />
	
    <title>Ian Chung Ye Earn | RV Senpai</title>
	
	<link rel="stylesheet" type="text/css" href="styles/style.css"/>
	<!-- Link for social media -->
	<!-- https://www.w3schools.com/howto/howto_css_social_media_buttons.asp -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"/>
	
	
</head>

<body>

<header>

	<?php
		include_once 'backtotop&scroll.php'
	?> 
	<nav>
		<?php
			include_once 'logo.php'
		?>
		<ul>
			<li><a href="index.php" title="RV Senpai HomePage">Home</a></li>
			<li><a class="active" href="aboutus.php" title="Abour RV Senpai">About Us</a></li>
			<li><div class="product_dropdown">
					<a class="dropbtn" href="product.php" title="RV Senpai RVs">Rental</a>
					<div id="product_dropdown_id" class="product_dropdown_content"></div>
				</div>
				</li>
			<li><a class="booking" href="enquiry.php" title="Rent Your RV Here">Booking</a></li>
			<li><a href="event.php" title="Event RV Senpai">Event</a></li>
			<li><a href="contactus.php" title="Contact RV Senpai">Contact Us</a></li>
		<li><button class="login" onclick="document.getElementById('id01').style.display='block'" style="width:auto;"><strong>Login</strong></button></li>
		</ul>
	</nav>
	
	

	
	
<!-- Login -->
<!-- Start here -->
<div id="id01" class="modal">
  <form class="modal-content animate" action="/action_page.php">
    <div class="imgcontainer">
      <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
      <img src="images/avatar.png" alt="Avatar" class="avatar" />
    </div>

    <div class="container">
      <label for="uname"><b>Email</b></label>
      <input type="text" class="log" placeholder="Enter Username" name="uname" required="requried" />
        
      <button type="submit" class="login login_nav">Login</button>
    </div>

    <div class="container" style="background-color:#f1f1f1">
      <button type="button" class="login cancelbtn" onclick="document.getElementById('id01').style.display='none'">Cancel</button>
    </div>
  </form>
</div>
<!-- End here -->
</header>

	<div class="bigimg_aboutus">
		<div class="caption">
		<h1><span class="border">Ian Chung Ye Earn</span></h1>
		</div>
	</div>

	<aside class="white_background-article">
		<div class="aboutme">
			<img src="images/ian2.jpg" alt="Ian's cute face"/>
			<p class="name">Ian Chung Ye Earn</p>
			<p class="number">100080073</p>
			<p class="course">BA-ICT</p>
			<table class="aboutme_table">
			<caption>Contribution Table</caption>
			<tr>
			<th>Contribution</th>
			<th>Details</th>
			</tr>
			<tr>
			<td>CSS</td>
			<td>Contribute the more button, </td>
			</tr>
			<tr>
			<td>HTML</td>
			<td>contribute in FAQ, form description and input, about us page, enquiry(booking), </td>
			</tr>
			<tr>
			<td>faq.html</td>
			<td>Information Contributed</td>
			</tr>
			<tr>
			<td>product1.html</td>
			<td>Images and description contributed</td>
			</tr>
			<tr>
			<td>product2.html</td>
			<td>Images and description contributed</td>
			</tr>
			<tr>
			<td>product3.html</td>
			<td>Images and description contributed</td>
			</tr>
			<tr>
			<td>product4.html</td>
			<td>Images and description contributed</td>
			</tr>
			<tr>
			<td>aboutus.html</td>
			<td>Information of images and information contributed</td>
			</tr>
			<tr>
			<td>Images</td>
			<td>Searching images</td>
			</tr>
			<tr>
			<td>Information</td>
			<td>Contribute most of the description</td>
			</tr>
			</table>
		</div>
	</aside>
	
	<div class="bigimg_aboutus">
		<div class="caption">
		<h2><span class="border2">Bring You Fly</span></h2>
		</div>
	</div>
	
<footer>
	

		<ul>
			<li><a href="partnership.php" title="RV Senpai Partners">Partnership</a></li>
			<li><a href="faq.php" title="RV Senpai FAQ">FAQ</a></li>
			<li><a href="photo.php" title="Photo Gallery">Photo Gallery</a></li>
			<li><a href="feedback.php" title="RV Senpai Feedback Form">Feedback</a></li>
			<li><a href="enhancements.php" title="RV Senpai Website Enhancements">Enhancements</a></li>
			<li><a href="enhancements2.php" title="RV Senpai Website Enhancements">Enhancements2</a></li>
			<li><a href="disclaimer.php" title="Disclaimer">Disclaimer</a></li>
		</ul>
	
	<?php
		include_once 'footer_link.php'
	?>	

	
	
</footer>
</body>
<script src="script/script.js"></script>
<script src="script/enhancements.js"></script>
</html>
