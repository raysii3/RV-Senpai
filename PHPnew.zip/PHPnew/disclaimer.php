<!DOCTYPE html>
<html lang='en'>

<head>
    <meta charset="utf-8" />
    <meta name="description" content="RV Senpai Project/Assignment" />
    <meta name="keywords" content="RV, Senpai, Disclaimer Page" />
    <meta name="author" content="Ericson Tan Peng Hong, Loo Wei Jit, Raymond Sii Li Sheng, Ian Chung Ye Earn" />
	
    <title>Disclaimer | RV Senpai</title>
	
	<link rel="stylesheet" type="text/css" href="styles/style.css"/>
	<!-- Link for social media -->
	<!-- https://www.w3schools.com/howto/howto_css_social_media_buttons.asp -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"/>
	
	
</head>

<body>

<header>

	<?php
		include_once 'backtotop&scroll.php'
	?> 
	<nav>
	<?php
			include_once 'logo.php'
		?>
		<ul>
			<li><a href="index.php" title="RV Senpai HomePage">Home</a></li>
			<li><a href="aboutus.php" title="About RV Senpai">About Us</a></li>
			<li><div class="product_dropdown">
					<a class="dropbtn" href="product.php" title="RV Senpai RVs">Rental</a>
					<div id="product_dropdown_id" class="product_dropdown_content"></div>
				</div>
				</li>
			<li><a class="booking" href="enquiry.php" title="Rent Your RV Here">Booking</a></li>
			<li><a href="event.php" title="Event RV Senpai">Event</a></li>
			<li><a href="contactus.php" title="Contact RV Senpai">Contact Us</a></li>
		<li><button class="login" onclick="document.getElementById('id01').style.display='block'" style="width:auto;"><strong>Login</strong></button></li>
		</ul>
	</nav>
	
	

	
	
<!-- Login -->
<!-- Start here -->
<div id="id01" class="modal">
  <form class="modal-content animate" action="/action_page.php">
    <div class="imgcontainer">
      <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
      <img src="images/avatar.png" alt="Avatar" class="avatar" />
    </div>

    <div class="container">
      <label for="uname"><b>Email</b></label>
      <input type="text" class="log" placeholder="Enter Username" name="uname" required="requried" />
        
      <button type="submit" class="login login_nav">Login</button>
    </div>

    <div class="container" style="background-color:#f1f1f1">
      <button type="button" class="login cancelbtn" onclick="document.getElementById('id01').style.display='none'">Cancel</button>
    </div>
  </form>
</div>
<!-- End here -->

</header>

	<div class="bigimg_disclaimer">
		<div class="caption">
		<h1><span class="border">RV Senpai</span></h1>
		</div>
	</div>

	<article class="article_area">
		<h3 class="h3_black_background">Disclaimer</h3>
		<h4>Read This</h4>
		<p>This website is created mainly for educational and non-commercial use only. It is a partialfulfilment for completion of unit COS10011 - Creating Web Applications  offered in Swinburne University of Technology, Sarawak Campus for Semester 1, 2018.</p>
		<p>The web-master and author(s) do not represent the business entity.</p>
		<p>The content of the pages of this website might be out‐dated or inaccurate, thus, the author(s) and web‐master does not take any responsibility for incorrect information disseminate or cited from this website.</p>
		<p>If you believe that information of any kind on this website is an infringement of copyright in material in which you either own copyright or are authorized to exercise the rights of a copyright owner, kindly contact the web-master (<a id="dis_link" href="mailto:100079958@students.swinburne.edu.my" target="_top" title="Student Email">100079958@students.swinburne.edu.my</a>) for removal.</p>
	</article>
	
	<div class="bigimg_disclaimer">
		<div class="caption">
		<h2><span class="border2">Rules!</span></h2>
		</div>
	</div>

	
<footer>

		<ul>
			<li><a href="partnership.php" title="RV Senpai Partners">Partnership</a></li>
			<li><a href="faq.php" title="RV Senpai FAQ">FAQ</a></li>
			<li><a href="photo.php" title="Photo Gallery">Photo Gallery</a></li>
			<li><a href="feedback.php" title="RV Senpai Feedback Form">Feedback</a></li>
			<li><a href="enhancements.php" title="RV Senpai Website Enhancements">Enhancements</a></li>
			<li><a href="enhancements2.php" title="RV Senpai Website Enhancements">Enhancements2</a></li>
			<li><a class="footer_active" href="disclaimer.php" title="Disclaimer">Disclaimer</a></li>
		</ul>
	
	<?php
		include_once 'footer_link.php'
	?>

	
	
</footer>
</body>

<script src="script/script.js"></script>
<script src="script/enhancements.js"></script>
</html>
