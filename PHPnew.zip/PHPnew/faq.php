<!DOCTYPE html>
<html lang='en'>

<head>
	<meta charset="utf-8" />
    <meta name="description" content="RV Senpai Project/Assignment" />
    <meta name="keywords" content="FAQ, Frequent, Ask, Question " />
    <meta name="author" content="Ericson Tan Peng Hong, Loo Wei Jit, Raymond Sii Li Sheng, Ian Chung Ye Earn" />
	
	<title>RV FAQ | RV Senpai</title>
	
	<link rel="stylesheet" type="text/css" href="styles/style.css"/>
	<!-- Link for social media -->
	<!-- https://www.w3schools.com/howto/howto_css_social_media_buttons.asp -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"/>

	
	
</head>

<body>

<header>

	<?php
		include_once 'backtotop&scroll.php'
	?>
	
	<nav>
	<?php
			include_once 'logo.php'
		?>
		<ul>
			<li><a href="index.php" title="RV Senpai HomePage">Home</a></li>
			<li><a href="aboutus.php" title="About RV Senpai">About Us</a></li>
			<li><div class="product_dropdown">
					<a class="dropbtn" href="product.php" title="RV Senpai RVs">Rental</a>
					<div id="product_dropdown_id" id="product_dropdown_id" class="product_dropdown_content"></div>
				</div>
				</li>
			<li><a class="booking" href="enquiry.php" title="Rent Your RV Here">Booking</a></li>
			<li><a href="event.php" title="Event RV Senpai">Event</a></li>
			<li><a href="contactus.php" title="Contact RV Senpai">Contact Us</a></li>
		<li><button class="login" onclick="document.getElementById('id01').style.display='block'" style="width:auto;"><strong>Login</strong></button></li>
		</ul>
	</nav>
	
	

	
	
<!-- Login -->
<!-- Start here -->
<div id="id01" class="modal">
  <form class="modal-content animate" action="/action_page.php">
    <div class="imgcontainer">
      <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
      <img src="images/avatar.png" alt="Avatar" class="avatar" />
    </div>

    <div class="container">
      <label for="uname"><b>Email</b></label>
      <input type="text" class="log" placeholder="Enter Username" name="uname" required="requried" />
        
      <button type="submit" class="login login_nav">Login</button>
    </div>

    <div class="container" style="background-color:#f1f1f1">
      <button type="button" class="login cancelbtn" onclick="document.getElementById('id01').style.display='none'">Cancel</button>
    </div>
  </form>
</div>
<!-- End here -->
</header>

	<div class="bigimg_faq">
		<div class="caption">
			<h1><span class="border">Enjoy The Trip</span></h1>
		</div>
	</div>
	
	<article>
		<div class="article_area">
		<h3 class="h3_black_background">FAQ</h3>
		<h4>Find Your Answer</h4>
		
		
		
		<ol>
		<li>
		<p class="faq" id="f_q1">What Type Of RV Is Suitable For Me?</p>
		<p class="p_ans"><span class="ans">Ans:</span> The type of RV for you is mainly depends on how large you travel group is. But you may also choose the RV according to the luxurious level you want.</p>
		</li>
		<li>
		<p class="faq" id="f_q2">Do I require a special license to operate a RV?</p>
		<p class="p_ans"><span class="ans">Ans:</span> Operating a small model RV only require a normal driver license. But for operating a big model RV such as the class A RV will require a heavy vehicles license.</p>
		</li>
		<li>
		<p class="faq" id="f_q3">How do I get the RV when I rent one?</p>
		<p class="p_ans"><span class="ans">Ans:</span> You may consider our delivery services or if you want to collect the vehicle by yourself, do feel free to stop by our vehicle compound. For rental that includes driver, the driver will pick you and your group by the time stated beyond booking.</p>
		</li>
		<li>
		<p class="faq" id="f_q4">When will my first day of rental start?</p>
		<p class="p_ans"><span class="ans">Ans:</span> The first day of your rental will starts as soon as you took your RV instead of the day you rent. However you should contact RV Senpai for confirmation of the day you want to take your rented RV.</p>
		</li>
		<li>
		<p class="faq" id="f_q5">What will happen if I broke some part of the RV?</p>
		<p class="p_ans"><span class="ans">Ans:</span> You may need to repay the price of the broken spare part depending on the price that it will cost to fix it. But it would be appreciated if you return the RV safe and sound.</p>
		</li>
		<li>
		<p class="faq" id="f_q6">How much is the deposit?</p>
		<p class="p_ans"><span class="ans">Ans:</span> The deposit will be the 20% of your total payment. For example, if you are renting a Premium Class B RV, your deposit will be RM200 of the total payment RM1000.</p>
		</li>
		<li>
		<p class="faq" id="f_q7">How do I make my payment?</p>
		<p class="p_ans"><span class="ans">Ans:</span> You may select your prefer payment method. RV Senpai accept all kinds of payment range from cryptocurrency to online backing, PayPal, AliPay, ApplePay, GooglePay, SamsungPay, Credit Card and Cash.</p>
		</li>
		<li>
		<p class="faq" id="f_q8">How do I know that I have successfully rented a RV?</p>
		<p class="p_ans"><span class="ans">Ans:</span> You will get a email confirmation from RV Senpai and also we will ask you about the date that you want to take your RV. If email confirmation have not been sent. Please be patient as RV Senpai is trying to reach to all our customer personally.</p>
		</li>
		</ol>
		<p class="more_button_black_background"><a href="contactus.html" title="Contact RV Senpai">Send Us Your Questions</a></p>
		</div>
	</article>
	
	<div class="bigimg_faq">
		<div class="caption">
			<h1><span class="border">Without Question</span></h1>
		</div>
	</div>


<footer>

		<ul>
			<li><a href="partnership.php" title="RV Senpai Partners">Partnership</a></li>
			<li><a class="footer_active" href="faq.php" title="RV Senpai FAQ">FAQ</a></li>
			<li><a href="photo.php" title="Photo Gallery">Photo Gallery</a></li>
			<li><a href="feedback.php" title="RV Senpai Feedback Form">Feedback</a></li>
			<li><a href="enhancements.php" title="RV Senpai Website Enhancements">Enhancements</a></li>
			<li><a href="enhancements2.php" title="RV Senpai Website Enhancements">Enhancements2</a></li>
			<li><a href="disclaimer.php" title="Disclaimer">Disclaimer</a></li>
		</ul>
		
	<?php
		include_once 'footer_link.php'
	?>

	
</footer>

</body>
<script src="script/script.js"></script>
<script src="script/enhancements.js"></script>	
</html>
